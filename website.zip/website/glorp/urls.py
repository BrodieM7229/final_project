from django.urls import path

from . import views

app_name = 'glorp'
urlpatterns = [
    # Home page
    path('', views.index, name='index'),
    path('projects/', views.projects, name='projects'),
    path('questions/', views.questions, name = 'questions'),
    path('answers/', views.answers, name='answers'),
    path('graph/', views.graph, name='graph'),

]