from django.shortcuts import render, redirect
from .models import Project, Question
import plotly.express as px
from plotly.offline import plot
import pandas as pd
from django.utils.safestring import mark_safe

# Create your views here.

def index(request):
    return render(request, 'glorp/index.html')

def projects(request):
    projects = Project.objects.all()
    return render(request, 'glorp/projects.html', {'projects':projects})

def questions(request):
    if request.method == 'POST':
        question_text = request.POST.get('question')
        if question_text:
            Question.objects.create(question_text=question_text)
            return redirect('glorp:answers')
    return render(request, 'glorp/questions.html')

def answers(request):
    questions = Question.objects.all()
    return render(request, 'glorp/answers.html', {'questions': questions})

def graph(request):
        data = {
            "Episode Title": [
                "Goodbye, Michael", "Dinner Party", "Stress Relief", "Niagara",
                "Casino Night", "The Job", "Booze Cruise", "The Injury",
                "Finale", "A.A.R.M."
            ],
            "IMDb Rating": [9.8, 9.4, 9.4, 9.3, 9.3, 9.2, 9.2, 9.1, 9.1, 9.0]
        }

        df = pd.DataFrame(data)
        fig = px.bar(
            df,
            x="Episode Title",
            y="IMDb Rating",
            title="Top 10 Highest-Rated Episodes of The Office (U.S.)",
            labels={"IMDb Rating": "IMDb Rating", "Episode Title": "Episode"},
            color="IMDb Rating",
            color_continuous_scale="Viridis"
        )
        fig.update_layout(xaxis_tickangle=-45)

        # Ensure `plot_div` is safe for Django templates
        plot_div = mark_safe(plot(fig, output_type='div', include_plotlyjs=True))

        return render(request, 'glorp/graph.html', {'plot_div': plot_div})
